import { useEffect, useState } from 'react'
import { Navbar } from './components/layout/Navbar'
import { Hero } from './features/home/Hero'
import { HowItWorks } from './features/home/HowItWorks'
import { FeaturedContests } from './features/home/FeaturedContests'
import { Testimonials } from './features/home/Testimonials'
import { CtaBanner } from './features/home/CtaBanner'
import { Footer } from './components/layout/Footer'
import { Register } from './pages/Register'

function App() {
  const [activeRoute, setActiveRoute] = useState(
    window.location.hash === '#/register' ? 'register' : 'home'
  )

  useEffect(() => {
    function onHashChange() {
      setActiveRoute(window.location.hash === '#/register' ? 'register' : 'home')
    }

    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  if (activeRoute === 'register') {
    return <Register />
  }

  return (
    <div className="min-h-screen min-w-0 bg-white font-sans text-gray-800 antialiased">
      <Navbar />
      <main>
        <Hero />
        <HowItWorks />
        <FeaturedContests />
        <Testimonials />
        <CtaBanner />
      </main>
      <Footer />
    </div>
  )
}

export default App
