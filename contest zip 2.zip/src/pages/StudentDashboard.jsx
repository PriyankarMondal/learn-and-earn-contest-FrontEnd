import { BrandLogo } from '../components/common/BrandLogo'

export function StudentDashboard() {
  return (
    <div className="flex min-h-screen bg-[#f6f9f3] font-sans text-gray-800">
      
      {/* Sidebar */}
      <aside className="flex w-[260px] flex-col justify-between border-r border-[#e2e8d5] bg-[#f6f9f3] py-6 px-4 shrink-0 hidden md:flex">
        <div>
          <div className="mb-10 px-2">
            <BrandLogo className="h-8 w-auto" />
          </div>
          <nav className="flex flex-col gap-2">
            <a href="#/dashboard" className="flex items-center gap-3 bg-[#e6eccd] px-4 py-3 text-sm font-bold text-[#446611] rounded-lg relative overflow-hidden">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#82c600]"></div>
              <svg className="w-5 h-5 opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></svg>
              Overview
            </a>
            <a href="#/dashboard" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
              My Learning
            </a>
            <a href="#/dashboard" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
              Contests
            </a>
            <a href="#/dashboard" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Earnings
            </a>
            <a href="#/dashboard" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
              Settings
            </a>
          </nav>
        </div>
        
        <div className="flex flex-col gap-2">
          <div className="bg-[#e9eed6] p-4 rounded-xl mb-4 border border-[#e2e8d5]/50">
            <h4 className="text-[11px] uppercase font-extrabold text-[#446611] tracking-wider mb-1">Scholar Pro</h4>
            <p className="text-[10px] text-[#698a28] font-medium leading-tight mb-3">Unlock premium contests and mentorship.</p>
            <button className="w-full bg-[#446611] text-white text-xs font-semibold py-2.5 rounded-lg hover:bg-[#38550e] transition-colors shadow-sm">
              Upgrade to Pro
            </button>
          </div>
          
          <a href="#/dashboard" className="flex items-center gap-3 px-4 py-2 text-sm font-semibold text-gray-500 hover:text-gray-800 transition-colors">
            <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            Support
          </a>
          <a href="#/login" className="flex items-center gap-3 px-4 py-2 text-sm font-semibold text-gray-500 hover:text-gray-800 transition-colors">
            <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Logout
          </a>
        </div>
      </aside>

      {/* Main Content Split */}
      <main className="flex-1 flex flex-col min-w-0">
        
        {/* Top Header */}
        <header className="flex items-center justify-between px-8 py-5">
          <div className="relative w-full max-w-[480px]">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            <input 
              type="text" 
              placeholder="Search for courses, contests, or scholars..." 
              className="w-full pl-10 pr-4 py-2.5 bg-[#e9eed6] border-transparent rounded-full text-sm font-medium focus:bg-white focus:border-gray-200 focus:ring-2 focus:ring-lime-500/20 outline-none transition-all placeholder-gray-500 text-gray-800"
            />
          </div>
          
          <div className="flex items-center gap-6">
            <button className="relative text-gray-500 hover:text-gray-800 transition-colors">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
            </button>
            <button className="text-gray-500 hover:text-gray-800 transition-colors">
               <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </button>
            
            <div className="flex items-center gap-3 border-l border-gray-200 pl-6 cursor-pointer group">
              <div className="text-right">
                <div className="text-sm font-bold text-gray-900 group-hover:text-[#446611]">Alex Rivera</div>
                <div className="text-[9px] font-extrabold text-amber-500 uppercase tracking-widest mt-0.5">Gold Tier Scholar</div>
              </div>
              <div className="w-10 h-10 rounded-full border-2 border-amber-400 overflow-hidden bg-white shrink-0 relative">
                <img src="https://ui-avatars.com/api/?name=Alex+Rivera&background=0d9488&color=fff" alt="User avatar" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content Grid */}
        <div className="flex-1 overflow-auto p-8 pt-4">
          <div className="flex flex-col xl:flex-row gap-8">
            
            <div className="flex-1 flex flex-col min-w-0">
              {/* Hero Banner */}
              <div className="bg-gradient-to-r from-[#4d7013] to-[#82c600] rounded-2xl p-8 relative overflow-hidden shadow-sm mb-8 text-white min-h-[220px] flex flex-col justify-center">
                <div className="absolute right-[-10%] top-[-20%] w-[300px] h-[300px] opacity-10 pointer-events-none">
                  <svg viewBox="0 0 100 100" fill="currentColor"><path d="M50 0L65.45 30.9L97.55 35.45L74.3 58.05L79.8 90.45L50 74.8L20.2 90.45L25.7 58.05L2.45 35.45L34.55 30.9L50 0Z"/></svg>
                </div>
                <div className="absolute right-[15%] bottom-[-10%] w-[150px] h-[150px] opacity-10 pointer-events-none">
                  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L1 9l4 2.18v6L12 21l7-3.82v-6l2.81-1.53V17h2V8.45L12 3z"/></svg>
                </div>
                
                <div className="relative z-10 max-w-lg">
                  <h1 className="text-[34px] font-bold tracking-tight mb-3">Welcome Back, Scholar</h1>
                  <p className="text-white/90 text-lg leading-snug mb-8">
                    Your intellectual journey continues. You've completed 85% of your weekly goals. Ready to tackle the new challenges?
                  </p>
                  <button className="bg-[#f9bd1c] hover:bg-[#e6ae1a] text-amber-950 font-bold px-6 py-2.5 rounded-lg inline-flex items-center gap-2 shadow-sm transition-transform active:scale-95">
                    Resume Learning <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                  </button>
                </div>
              </div>

              {/* Performance Matrix Header */}
              <div className="flex justify-between items-end mb-4">
                <h2 className="text-lg font-bold text-gray-900 tracking-tight">Performance Matrix</h2>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#a3a3a3]">Global Analytics</span>
              </div>

              {/* 3 KPI Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
                <div className="bg-[#f1f4e8] rounded-xl p-5 shadow-[inset_0_1px_rgba(255,255,255,0.8)] border border-[#e2e8d5]/50 flex flex-col relative overflow-hidden">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 rounded shadow-sm bg-[#e7edd3] text-[#5c8020] flex items-center justify-center">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    </div>
                    <span className="bg-[#e4ebce] text-[#446611] text-[10px] font-extrabold px-2 py-0.5 rounded tracking-wide">TOP 2%</span>
                  </div>
                  <h3 className="text-[11px] font-extrabold uppercase tracking-widest text-gray-500 mb-1">Overall Rank</h3>
                  <p className="text-4xl font-black text-gray-900 tracking-tight">#124</p>
                </div>

                <div className="bg-[#f1f4e8] rounded-xl p-5 shadow-[inset_0_1px_rgba(255,255,255,0.8)] border border-[#e2e8d5]/50 flex flex-col relative overflow-hidden">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 rounded shadow-sm bg-[#e7edd3] text-[#5c8020] flex items-center justify-center">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>
                    </div>
                    <span className="bg-[#e4ebce] text-[#446611] text-[10px] font-extrabold px-2 py-0.5 rounded tracking-wide">+2.4 pts</span>
                  </div>
                  <h3 className="text-[11px] font-extrabold uppercase tracking-widest text-gray-500 mb-1">Avg Score</h3>
                  <p className="text-4xl font-black text-gray-900 tracking-tight">94.8</p>
                </div>

                <div className="bg-[#f1f4e8] rounded-xl p-5 shadow-[inset_0_1px_rgba(255,255,255,0.8)] border border-[#e2e8d5]/50 flex flex-col relative overflow-hidden">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 rounded shadow-sm bg-[#e9e3cc] text-amber-700 flex items-center justify-center">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                    </div>
                    <span className="bg-amber-400 text-amber-950 text-[10px] font-extrabold px-2 py-0.5 rounded tracking-wide uppercase">Withdraw</span>
                  </div>
                  <h3 className="text-[11px] font-extrabold uppercase tracking-widest text-gray-500 mb-1">Total Earnings</h3>
                  <p className="text-4xl font-black text-gray-900 tracking-tight">$1,420</p>
                </div>
              </div>

              {/* Active Learning Section */}
              <h2 className="text-lg font-bold text-gray-900 tracking-tight mb-4">Active Learning</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-10">
                <div className="bg-[#f1f4e8] rounded-xl p-6 shadow-[inset_0_1px_rgba(255,255,255,0.8)] border border-[#e2e8d5]/50 flex flex-col relative overflow-hidden">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-2 h-2 rounded-full bg-red-500"></div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-gray-500">Ongoing Contest</span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 leading-tight mb-2">Advanced Algorithmic Patterns</h3>
                  <p className="text-sm text-gray-600 mb-8 max-w-[90%]">Master complex data structures and heuristic optimizations.</p>
                  
                  <div className="mt-auto">
                    <div className="flex justify-between items-end mb-2">
                      <span className="text-xs font-bold text-gray-900">64% Completed</span>
                      <span className="text-[10px] uppercase font-bold text-gray-400">Deadline: 2 Days</span>
                    </div>
                    <div className="w-full bg-[#dbe2c9] rounded-full h-1.5"><div className="bg-[#82c600] h-1.5 rounded-full" style={{width: '64%'}}></div></div>
                  </div>
                </div>

                <div className="bg-[#446611] rounded-xl p-6 shadow-sm border border-[#3d5a0f] flex flex-col relative overflow-hidden text-white">
                  <div className="absolute right-[-10%] top-[-10%] w-[150px] h-[150px] opacity-5 pointer-events-none">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4 11h-3v3c0 .55-.45 1-1 1s-1-.45-1-1v-3H8c-.55 0-1-.45-1-1s.45-1 1-1h3V8c0-.55.45-1 1-1s1 .45 1 1v3h3c.55 0 1 .45 1 1s-.45 1-1 1z"/></svg>
                  </div>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-10 h-10 rounded shadow-sm bg-white/10 flex items-center justify-center">
                      <svg className="w-5 h-5 text-lime-100" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    </div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#82c600]">Up Next</span>
                  </div>
                  <h3 className="text-xl font-bold leading-tight mb-2 pr-4">System Design Masters</h3>
                  <p className="text-sm text-lime-100/80 mb-6">Workshop starts in 45 minutes.</p>
                  <div className="mt-auto">
                    <button className="bg-white text-[#446611] text-[11px] font-extrabold tracking-widest uppercase px-5 py-2.5 rounded shadow-sm hover:bg-gray-50 transition-colors">Join Session</button>
                  </div>
                </div>
              </div>

              {/* Featured Contests header */}
              <div className="flex justify-between items-end mb-4">
                <h2 className="text-lg font-bold text-gray-900 tracking-tight">Featured Contests</h2>
                <a href="#/dashboard" className="text-[10px] font-extrabold uppercase tracking-widest text-[#5c8020] hover:underline">View All</a>
              </div>
              
              {/* Featured Contests List */}
              <div className="flex flex-col gap-4">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 pr-6 flex items-center gap-5 overflow-hidden">
                  <div className="w-[180px] h-28 bg-[#1e293b] rounded-lg shrink-0 relative overflow-hidden">
                    <div className="absolute inset-0 bg-blue-500/20 mix-blend-overlay"></div>
                    {/* Placeholder abstract design for cyber */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg className="w-10 h-10 text-cyan-400 opacity-70" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0 py-2">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="bg-amber-100 text-amber-800 text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded">Premium</span>
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Mar 24 - Apr 01</span>
                    </div>
                    <h3 className="text-base font-bold text-gray-900 truncate">Cyber-Security Sprint 2024</h3>
                    <p className="text-sm text-gray-500 mt-0.5 truncate">Vulnerability assessment and heuristic penetration checks.</p>
                  </div>
                  <div className="px-6 border-l border-gray-100 flex flex-col items-center shrink-0">
                    <div className="text-[10px] font-extrabold uppercase tracking-widest text-gray-400 mb-0.5">Prize Pool</div>
                    <div className="text-xl font-black text-[#5c8020] mb-2">$2,500</div>
                    <button className="bg-gray-900 hover:bg-gray-800 text-white text-xs font-bold px-5 py-2 rounded-lg w-full transition-colors shadow-sm">Register</button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 pr-6 flex items-center gap-5 overflow-hidden">
                  <div className="w-[180px] h-28 bg-[#1e293b] rounded-lg shrink-0 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[#82c600]/20 mix-blend-overlay"></div>
                    {/* Placeholder abstract design for AI */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg className="w-10 h-10 text-lime-400 opacity-70" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0 py-2">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="bg-lime-100 text-[#446611] text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded">Open</span>
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Apr 05 - Apr 15</span>
                    </div>
                    <h3 className="text-base font-bold text-gray-900 truncate">AI & Machine Learning Bowl</h3>
                    <p className="text-sm text-gray-500 mt-0.5 truncate">Build predictive models using raw algorithmic frameworks.</p>
                  </div>
                  <div className="px-6 border-l border-gray-100 flex flex-col items-center shrink-0">
                    <div className="text-[10px] font-extrabold uppercase tracking-widest text-gray-400 mb-0.5">Prize Pool</div>
                    <div className="text-xl font-black text-[#5c8020] mb-2">$5,000</div>
                    <button className="bg-gray-900 hover:bg-gray-800 text-white text-xs font-bold px-5 py-2 rounded-lg w-full transition-colors shadow-sm">Register</button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right Sidebar Block */}
            <div className="w-full xl:w-[320px] flex flex-col shrink-0 gap-6">
              
              {/* Leaderboard Card */}
              <div className="bg-[#f1f4e8] rounded-xl p-6 border border-[#e2e8d5]/50 shadow-[inset_0_1px_rgba(255,255,255,0.8)]">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-[13px] font-extrabold uppercase tracking-widest text-gray-900">Top Scholars</h3>
                  <svg className="w-4 h-4 text-[#5c8020]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" /></svg>
                </div>
                
                {/* User Highlight Block */}
                <div className="bg-[#446611] rounded-xl p-4 flex items-center justify-between mb-6 shadow-md relative overflow-hidden">
                  <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-[#38550e] to-transparent pointer-events-none"></div>
                  <div className="flex items-center gap-4">
                    <div className="text-xl font-black text-white/90">124</div>
                    <div className="w-9 h-9 rounded-full bg-white/20 p-0.5 shrink-0 overflow-hidden">
                      <img src="https://ui-avatars.com/api/?name=Alex+Rivera&background=0d9488&color=fff" className="w-full h-full rounded-full" alt="Alex" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white leading-tight">Alex Rivera <span className="text-[10px] font-medium text-lime-200">(You)</span></div>
                      <div className="text-[10px] font-bold text-lime-300">2,480 XP</div>
                    </div>
                  </div>
                  <svg className="w-4 h-4 text-[#82c600] relative z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                </div>
                
                {/* List */}
                <div className="flex flex-col gap-4">
                  {[
                    { rank: "01", name: "Sarah Chen", xp: "4,920 XP", avatar: "SC", badge: true },
                    { rank: "02", name: "David Miller", xp: "4,815 XP", avatar: "DM" },
                    { rank: "03", name: "Elena Rodriguez", xp: "4,790 XP", avatar: "ER" }
                  ].map((scholar, idx) => (
                    <div key={idx} className="flex items-center justify-between group">
                      <div className="flex items-center gap-4">
                        <div className={`text-sm font-bold ${scholar.rank === '01' ? 'text-amber-500' : 'text-gray-400'}`}>{scholar.rank}</div>
                        <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-500 flex justify-center items-center text-xs font-bold overflow-hidden shrink-0">
                          <img src={`https://ui-avatars.com/api/?name=${scholar.avatar}&background=1e293b&color=fff`} className="w-full h-full object-cover" alt={scholar.avatar} />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-gray-900 leading-tight group-hover:text-[#446611] transition-colors">{scholar.name}</div>
                          <div className="text-[10px] font-bold text-gray-400">{scholar.xp}</div>
                        </div>
                      </div>
                      {scholar.badge && (
                        <div className="w-5 h-5 rounded-full bg-amber-100 flex justify-center items-center">
                          <svg className="w-3 h-3 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" /></svg>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                
                <button className="w-full mt-6 py-2.5 rounded-lg border border-[#e2e8d5] text-[10px] font-extrabold uppercase tracking-widest text-gray-500 hover:bg-white hover:text-[#446611] transition-colors shadow-sm">
                  View Full Leaderboard
                </button>
              </div>

              {/* Learning Insights */}
              <div className="bg-[#e4ebce] rounded-xl p-6 shadow-sm border border-[#d6e0b7] relative overflow-hidden">
                <div className="absolute right-[-15%] bottom-[-15%] w-[150px] h-[150px] opacity-[0.03] pointer-events-none">
                   <svg viewBox="0 0 100 100" fill="currentColor"><path d="M50 0c27.614 0 50 22.386 50 50s-22.386 50-50 50S0 77.614 0 50 22.386 0 50 0zm0 18c-17.673 0-32 14.327-32 32s14.327 32 32 32 32-14.327 32-32-14.327-32-32-32zm0 15c9.389 0 17 7.611 17 17s-7.611 17-17 17-17-7.611-17-17 7.611-17 17-17z"/></svg>
                </div>
                <h3 className="text-[15px] font-bold text-gray-900 mb-6">Learning Insights</h3>
                
                <div className="flex flex-col gap-4">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center shrink-0">
                      <svg className="w-5 h-5 text-[#5c8020]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" /></svg>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-gray-900 mb-1">Analytical Thinking</h4>
                      <p className="text-[10px] text-gray-600 leading-snug">Grew by <span className="font-bold text-[#5c8020]">+12%</span> this week. Focus on system architecture next.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center shrink-0">
                      <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-gray-900 mb-1">Creative Problem Solving</h4>
                      <p className="text-[10px] text-gray-600 leading-snug">High potential identified in heuristic design contests.</p>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
            
          </div>
        </div>
      </main>
    </div>
  )
}
