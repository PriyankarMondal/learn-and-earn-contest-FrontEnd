import { BrandLogo } from '../components/common/BrandLogo'
// Force HMR Update

export function AdminDashboard() {
  return (
    <div className="flex min-h-screen bg-[#f6f9f3] font-sans text-gray-800">
      
      {/* Sidebar */}
      <aside className="flex w-[260px] flex-col justify-between border-r border-[#e2e8d5] bg-[#f6f9f3] py-6 px-4 shrink-0 hidden md:flex">
        <div>
          <div className="mb-10 px-2">
            <BrandLogo className="h-8 w-auto" />
          </div>
          <nav className="flex flex-col gap-2">
            <a href="#/admin" className="flex items-center gap-3 bg-[#e6eccd] px-4 py-3 text-sm font-bold text-[#446611] rounded-lg relative overflow-hidden">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#82c600]"></div>
              <svg className="w-5 h-5 opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></svg>
              Overview
            </a>
            <a href="#/admin" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path d="M12 2l3 6 6 .5-4.5 4.5 1 6-5.5-3-5.5 3 1-6L3 8.5l6-.5z"/></svg>
              Contests
            </a>
            <a href="#/admin" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Evaluations
            </a>
            <a href="#/admin" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 7a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" /></svg>
              User Management
            </a>
            <a href="#/admin" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" /></svg>
              Earnings
            </a>
            <a href="#/admin" className="flex items-center gap-3 px-4 py-3 text-sm font-semibold text-gray-600 hover:bg-[#e6eccd]/50 hover:text-[#446611] rounded-lg transition-colors">
              <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
              Settings
            </a>
          </nav>
        </div>
        
        <div className="flex flex-col gap-2">
          <div className="bg-[#e9eed6] p-4 rounded-xl mb-4">
            <p className="text-[10px] uppercase font-bold text-[#446611] tracking-widest mb-1.5">Pro Plan Active</p>
            <button className="w-full bg-[#446611] text-white text-xs font-semibold py-2.5 rounded-lg hover:bg-[#38550e] transition-colors shadow-sm">
              Upgrade to Pro
            </button>
          </div>
          
          <a href="#/admin" className="flex items-center gap-3 px-4 py-2 text-sm font-semibold text-gray-500 hover:text-gray-800 transition-colors">
            <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            Support
          </a>
          <a href="#/login" className="flex items-center gap-3 px-4 py-2 text-sm font-semibold text-gray-500 hover:text-gray-800 transition-colors">
            <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Logout
          </a>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        
        {/* Top Header */}
        <header className="flex items-center justify-between px-8 py-5">
          <div className="relative w-full max-w-sm">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            <input 
              type="text" 
              placeholder="Search contests, students, or reports..." 
              className="w-full pl-10 pr-4 py-2.5 bg-[#eff3e5] border-transparent rounded-full text-sm font-medium focus:bg-white focus:border-gray-200 focus:ring-2 focus:ring-lime-500/20 outline-none transition-all"
            />
          </div>
          
          <div className="flex items-center gap-6">
            <button className="relative text-gray-500 hover:text-gray-800 transition-colors">
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#f6f9f3]"></span>
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
            </button>
            <button className="text-gray-500 hover:text-gray-800 transition-colors">
               <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </button>
            
            <div className="flex items-center gap-3 border-l border-gray-200 pl-6 cursor-pointer group">
              <div className="text-right">
                <div className="text-sm font-bold text-gray-900 group-hover:text-[#446611]">Desun Admin</div>
                <div className="text-[10px] font-medium text-gray-500 uppercase tracking-widest">Super Administrator</div>
              </div>
              <div className="w-10 h-10 rounded-full border-2 border-lime-500 overflow-hidden bg-white shrink-0">
                <img src="https://ui-avatars.com/api/?name=Admin&background=f1f5f9&color=64748b" alt="Admin block" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-auto p-8 pt-2 relative">
          
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Desun Academy Command Center</h1>
            <p className="mt-1 text-gray-500 text-sm font-medium">Real-time overview of academic performance and contest lifecycle.</p>
          </div>

          {/* 4 KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-[#eff3e5] rounded-xl p-5 border border-white relative overflow-hidden shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="w-10 h-10 rounded-lg bg-[#e2ecce] text-[#698a28] flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" /></svg>
                </div>
                <span className="text-[10px] font-bold text-[#698a28] bg-white/50 px-2 py-1 rounded">+12% vs last month</span>
              </div>
              <h3 className="text-sm font-medium text-gray-500">Total Contests</h3>
              <p className="text-3xl font-bold text-gray-900 mt-1 tracking-tight">142</p>
            </div>

            <div className="bg-[#eff3e5] rounded-xl p-5 border border-white relative overflow-hidden shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="w-10 h-10 rounded-lg bg-[#e2ecce] text-[#698a28] flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                </div>
                <span className="text-[10px] font-bold text-[#698a28] bg-white/50 px-2 py-1 rounded">+2.4k new</span>
              </div>
              <h3 className="text-sm font-medium text-gray-500">Participants</h3>
              <p className="text-3xl font-bold text-gray-900 mt-1 tracking-tight">18.5k</p>
            </div>

            <div className="bg-[#eff3e5] rounded-xl p-5 border border-white relative overflow-hidden shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="w-10 h-10 rounded-lg bg-white border border-gray-100 text-[#446611] flex items-center justify-center shadow-sm">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>
                </div>
                <span className="text-[10px] font-bold text-red-600 bg-red-100/50 px-2 py-1 rounded">High Priority</span>
              </div>
              <h3 className="text-sm font-medium text-gray-500">Pending Evaluations</h3>
              <p className="text-3xl font-bold text-gray-900 mt-1 tracking-tight">89</p>
            </div>

            <div className="bg-[#eff3e5] rounded-xl p-5 border border-white relative overflow-hidden shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="w-10 h-10 rounded-lg bg-[#e2ecce] text-[#698a28] flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                </div>
                <span className="text-[10px] font-bold text-[#446611] bg-white/50 px-2 py-1 rounded">Peak Efficiency</span>
              </div>
              <h3 className="text-sm font-medium text-gray-500">Completion Rate</h3>
              <p className="text-3xl font-bold text-gray-900 mt-1 tracking-tight">94.2%</p>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-8">
            {/* Contest Management Table */}
            <div className="xl:col-span-2 bg-[#eff3e5] rounded-xl p-6 border border-white shadow-sm overflow-hidden flex flex-col">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-gray-900">Contest Management</h3>
                <a href="#/" className="text-xs font-bold text-[#5c8020] hover:underline flex items-center gap-1">View All <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg></a>
              </div>
              
              <div className="w-full overflow-x-auto">
                <table className="w-full text-left text-sm whitespace-nowrap">
                  <thead>
                    <tr className="text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-200/60">
                      <th className="pb-3 w-1/2">Contest Name</th>
                      <th className="pb-3">Status</th>
                      <th className="pb-3 text-right">Participants</th>
                      <th className="pb-3 text-right pr-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200/40">
                    <tr>
                      <td className="py-4">
                        <div className="font-bold text-gray-900 text-[13px]">Global Mathematics Olympiad 2024</div>
                        <div className="text-[11px] text-gray-500 mt-0.5">Closes in 2 days</div>
                      </td>
                      <td className="py-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded bg-lime-100 text-[#446611] text-[10px] font-extrabold uppercase tracking-wide">Live</span>
                      </td>
                      <td className="py-4 text-right font-medium text-gray-700">4,281</td>
                      <td className="py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button className="text-[#698a28] hover:text-[#446611]"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg></button>
                          <button className="text-[#698a28] hover:text-[#446611]"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 00-2-2m6 2h2a2 2 0 002-2v-6a2 2 0 00-2-2h-2m-6 0h.01M19 19h.01M16 11h.01M16 14h.01" /></svg></button>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-4">
                        <div className="font-bold text-gray-900 text-[13px]">Advanced Physics Challenge</div>
                        <div className="text-[11px] text-gray-500 mt-0.5">Review period</div>
                      </td>
                      <td className="py-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded bg-amber-100 text-amber-700 text-[10px] font-extrabold uppercase tracking-wide">Grading</span>
                      </td>
                      <td className="py-4 text-right font-medium text-gray-700">1,105</td>
                      <td className="py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button className="text-[#698a28] hover:text-[#446611]"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg></button>
                          <button className="text-[#698a28] hover:text-[#446611]"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg></button>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-4">
                        <div className="font-bold text-gray-900 text-[13px]">Digital Art & Design Sprint</div>
                        <div className="text-[11px] text-gray-500 mt-0.5">Ended July 15</div>
                      </td>
                      <td className="py-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded bg-gray-200 text-gray-600 text-[10px] font-extrabold uppercase tracking-wide">Archived</span>
                      </td>
                      <td className="py-4 text-right font-medium text-gray-700">942</td>
                      <td className="py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button className="text-[#698a28] hover:text-[#446611]"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg></button>
                          <button className="text-[#698a28] hover:text-[#446611]"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg></button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent Submissions Card */}
            <div className="bg-[#eff3e5] rounded-xl p-6 border border-white shadow-sm flex flex-col">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Recent Submissions</h3>
              <div className="flex flex-col gap-6">
                {[
                  { name: "Alex Rivera", subject: "Mathematics", time: "2m ago", status: "Review", avatar: "AR" },
                  { name: "Elena Kostic", subject: "Physics", time: "12m ago", status: "Review", avatar: "EK" },
                  { name: "Marcus Thorne", subject: "Literature", time: "45m ago", status: "Review", avatar: "MT" },
                  { name: "Sarah Jenkins", subject: "Design", time: "1h ago", status: "Checked", avatar: "SJ" }
                ].map((s, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-[#82c600] flex justify-center items-center text-white text-xs font-bold shrink-0">{s.avatar}</div>
                      <div>
                        <div className="text-sm font-bold text-gray-900">{s.name}</div>
                        <div className="text-[10px] text-gray-500 font-medium">{s.subject} • {s.time}</div>
                      </div>
                    </div>
                    <button className={`px-4 py-1.5 rounded-lg text-xs font-bold leading-none shrink-0 ${s.status === 'Review' ? 'bg-[#446611] text-white shadow-sm hover:bg-[#38550e]' : 'bg-gray-200 text-gray-500 cursor-default'}`}>
                      {s.status}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-20">
            {/* User Demographics */}
            <div className="bg-[#eff3e5] rounded-xl p-6 border border-white shadow-sm xl:col-span-1">
              <h3 className="text-base font-bold text-gray-900 mb-6">User Demographics</h3>
              <div className="space-y-5">
                <div>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="font-semibold text-gray-700">Undergraduate</span>
                    <span className="font-bold text-gray-900">62%</span>
                  </div>
                  <div className="w-full bg-[#e3e8d8] rounded-full h-1.5"><div className="bg-[#446611] h-1.5 rounded-full" style={{width: '62%'}}></div></div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="font-semibold text-gray-700">Postgraduate</span>
                    <span className="font-bold text-gray-900">28%</span>
                  </div>
                  <div className="w-full bg-[#e3e8d8] rounded-full h-1.5"><div className="bg-[#f9bd1c] h-1.5 rounded-full" style={{width: '28%'}}></div></div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="font-semibold text-gray-700">Professional</span>
                    <span className="font-bold text-gray-900">10%</span>
                  </div>
                  <div className="w-full bg-[#e3e8d8] rounded-full h-1.5"><div className="bg-[#b3b9a9] h-1.5 rounded-full" style={{width: '10%'}}></div></div>
                </div>
              </div>
            </div>

            {/* Academic Growth */}
            <div className="bg-[#38550e] rounded-xl p-6 border border-white shadow-sm flex flex-col xl:col-span-1 border-none relative overflow-hidden">
              <div className="absolute inset-x-0 bottom-0 top-1/2 bg-gradient-to-t from-[rgba(56,85,14,0.6)] to-transparent z-0"></div>
              <h3 className="text-base font-bold text-white mb-1 relative z-10">Academic Growth</h3>
              <p className="text-xs text-lime-100/70 font-medium relative z-10">Top Performing Segment</p>
              
              <div className="flex-1 flex items-end justify-between gap-2 mt-8 pb-4 relative z-10">
                <div className="w-full bg-white/20 rounded-t-sm" style={{height: '35%'}}></div>
                <div className="w-full bg-white/30 rounded-t-sm" style={{height: '45%'}}></div>
                <div className="w-full bg-white/40 rounded-t-sm relative" style={{height: '60%'}}></div>
                <div className="w-full bg-[#f9bd1c] rounded-t-sm" style={{height: '80%'}}></div>
                <div className="w-full bg-white/30 rounded-t-sm" style={{height: '55%'}}></div>
                <div className="w-full bg-white/20 rounded-t-sm" style={{height: '65%'}}></div>
              </div>
              <div className="flex justify-between items-center border-t border-white/10 pt-3 mt-auto relative z-10">
                <span className="text-xs font-bold text-amber-400">Postgraduate Leads</span>
                <span className="text-[9px] text-lime-200/50">Updated 1h ago</span>
              </div>
            </div>

            {/* Right side stacked cards */}
            <div className="xl:col-span-2 flex flex-col gap-6">
              
              <div className="bg-[#eff3e5] rounded-xl p-5 border border-white shadow-sm flex items-start justify-between relative overflow-hidden group">
                 <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#f9bd1c]"></div>
                 <div className="pl-3">
                   <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                     <span className="text-[#f9bd1c]"><svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg></span>
                     Winner Declaration
                   </h4>
                   <p className="text-xs text-gray-600 mt-2 max-w-[200px] leading-relaxed font-medium">Awaiting final scores for "Advanced Calculus Open".</p>
                   <div className="flex -space-x-2 mt-4">
                     <div className="w-6 h-6 rounded-full bg-lime-300 border-2 border-[#eff3e5] flex justify-center items-center text-[8px] font-bold">EK</div>
                     <div className="w-6 h-6 rounded-full bg-blue-300 border-2 border-[#eff3e5] flex justify-center items-center text-[8px] font-bold">AR</div>
                     <div className="w-6 h-6 rounded-full bg-purple-300 border-2 border-[#eff3e5] flex justify-center items-center text-[8px] font-bold">MT</div>
                   </div>
                 </div>
                 <button className="bg-[#f9bd1c]/20 hover:bg-[#f9bd1c]/40 text-[#b5870f] text-[10px] uppercase font-bold tracking-widest px-4 py-2 rounded-lg transition-colors mt-8">Select Now</button>
              </div>

              <div className="bg-[#eff3e5] rounded-xl p-5 border border-white shadow-sm flex-1">
                <h4 className="text-sm font-bold text-gray-900 mb-4">Admin Activity</h4>
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <div className="w-2 h-2 rounded-full bg-[#446611] shrink-0 mt-1.5"></div>
                    <div>
                      <p className="text-xs text-gray-800 font-semibold text-wrap">You published <span className="text-[#446611]">Summer Quiz Series</span></p>
                      <p className="text-[10px] text-gray-400 font-medium">10:24 AM</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-2 h-2 rounded-full bg-[#446611] shrink-0 mt-1.5"></div>
                    <div>
                      <p className="text-xs text-gray-800 font-semibold">System auto-archived 12 old contests</p>
                      <p className="text-[10px] text-gray-400 font-medium">09:00 AM</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          
          {/* Floating Action Button */}
          <button className="fixed bottom-8 right-8 w-14 h-14 bg-[#4d7313] hover:bg-[#3d5b0f] text-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-105 active:scale-95 shadow-[#4d7313]/30 z-50">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
          </button>

        </div>
      </main>
    </div>
  )
}
